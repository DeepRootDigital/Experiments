$(document).ready(function(){

	meSpeak.loadConfig("/ada/mespeak/mespeak_config.json");
	meSpeak.loadVoice('/ada/mespeak/en-us.json');
	meSpeak.speak('I am Aidaa, the Artificial Development Assistant, what is your name?', 'f2');

	function GetName() {
		usrname = $('input[name=name]').val();
		return usrname;
	}

	function Login(name) {
		if (name === '') {
			$('.dialogue').append('<p><b>ADA:</b> Im sorry construct but I must have your name.</p>');
			meSpeak.speak('I am sorry construct but I must have your name.');
			return false;
		}
		else {
			$('.dialogue').append('<p><b>ADA:</b> Logging you in '+name+'</p>');
			meSpeak.speak('Logging you in'+name);
		}
	}


	$('input[name=name-submit]').click(function(){	
		Login(GetName());
	});

	$('li').hover(function(){
		var speaktext = $(this).text();
		meSpeak.stop();
		meSpeak.speak(speaktext);
	});


	function RandomTaskDisplay() {
		var RandomNum = Math.floor((Math.random()*100)+1);
		$('.debug .container').empty();
		if (RandomNum >= 0 && RandomNum > 9) {
			$('.debug .container').append('<p><b>ADA</b> is running maintinance tasks on connected machines.</p>');
		}
		else if (RandomNum > 10 && RandomNum < 19) {
			$('.debug .container').append('<p><b>ADA</b> is watching videos on Add Me Fast</p>');
		}
		else {
			$('.debug .container').append('<p><b>ADA</b> is learning.</p>');
		}
	}

	RandomTaskDisplay();


	function RandomQuestions() {
		var name = GetName();
			$('.dialogue').append('<p><b>ADA:</b> What is your favorite drink?</p>');
			meSpeak.speak(name+' What is your favorite drink?');
	}

	RandomQuestions();

});