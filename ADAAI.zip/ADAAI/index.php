<html>
<head>
	<title>ADA - Artifical Developer Assistant</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
	<script type="text/javascript" src="mespeak/mespeak.full.js"></script>
	<script type="text/javascript" src="mespeak/mespeak.js"></script>
	<script type="text/javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
	<script type="text/javascript" src="function.js"></script>
</head>
<body>
	<div class="container">
		<div class="dialogue">
			<p><b>ADA:</b> Hello Construct.</p>
			<p><b>ADA:</b> I am ADA, Artifical Development Assistant what is your name?</p>
		</div>
	</div>

	<div class="ui">
		<div class="container">
			
			<input value="" name="name" type="text">
			<input name="name-submit" type="submit">

			<div class="Ada-Functions">
				<ul>
					<li>Language Functions</li>
					<li>Entertainment Functions</li>
					<li>Diagnostic Functions</li>
					<li>
						Systems Control Functions
						<ul>
							<li><a href="teamviewer8://remotecontrol?connectcc=110672532">Connect to Marrianes Computer</a></li>

							</ul>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="debug">
		<div class="container">
			<p><b>ADA</b> is thinking...</p>
		</div>
		</div
	</body>
	</html>