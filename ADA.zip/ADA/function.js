$(document).ready(function(){

	meSpeak.loadConfig("http://clients.businessonmarketst.com/ada/mespeak_config.json");
	meSpeak.loadVoice('http://clients.businessonmarketst.com/ada/en-us.json');

	$('p, li, h1, h2, h3, h4, h5, h6').hover(function() {
		var speaktext = $(this).text();
		meSpeak.stop();
		meSpeak.speak(speaktext);
	});


});